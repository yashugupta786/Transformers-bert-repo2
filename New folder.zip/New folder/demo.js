function getData() {
    let value = document.getElementById('leftInput').value;

    if (value) {
        document.getElementById("loader1").style.display = "block";
        document.getElementById("loader2").style.display = "block";
        $.ajax({
            type: 'POST',
            url: "http://192.168.0.103:1993/nmt_service",
            contentType: 'application/json',
            data: JSON.stringify({
                'data': value
            }),
            success: function (result) {
                document.getElementById('rightInput').value = JSON.parse(result).DATA;
                document.getElementById("loader1").style.display = "none";
                document.getElementById("loader2").style.display = "none";
            }
        });
    } else {
        alert("Enter Text!");
    }
}
function clearData(){
document.getElementById('leftInput').value = "";
document.getElementById('rightInput').value = "";
}